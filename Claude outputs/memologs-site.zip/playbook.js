/* The playbook: one data model, three densities.
   - wizard (fixed side card on desktop): the latest step expanded with its
     visual, earlier steps collapsed to icon rows, nine progress dots
   - strip (phones): icon + one line, tap to open
   - full (the dialog, and the close stage): every step with its visual and
     the draft-note interaction
   Everything here is an authored, fictional illustration. */
window.MLPlaybook = (function () {
  'use strict';
  var reduce = matchMedia('(prefers-reduced-motion: reduce)').matches;

  /* ---------------------------------------------------------- icons -- */
  var I = {
    goal: '<svg viewBox="0 0 24 24"><circle cx="12" cy="12" r="9"/><circle cx="12" cy="12" r="5"/><circle cx="12" cy="12" r="1.4" fill="currentColor" stroke="none"/></svg>',
    question: '<svg viewBox="0 0 24 24"><path d="M4 6.5A3.5 3.5 0 0 1 7.5 3h9A3.5 3.5 0 0 1 20 6.5v6a3.5 3.5 0 0 1-3.5 3.5H11l-4.5 4v-4A3.5 3.5 0 0 1 4 12.5z"/><path d="M10 8.2c.5-1.4 4-1.5 4 .4 0 1.3-2 1.4-2 3"/><circle cx="12" cy="13.6" r=".7" fill="currentColor" stroke="none"/></svg>',
    bet: '<svg viewBox="0 0 24 24"><path d="M3 17 9 11l4 4 8-8"/><path d="M15 7h6v6"/></svg>',
    rules: '<svg viewBox="0 0 24 24"><path d="M12 3 4.5 6v6c0 4.5 3.2 7.6 7.5 9 4.3-1.4 7.5-4.5 7.5-9V6z"/><path d="m9 12 2 2 4-4"/></svg>',
    experience: '<svg viewBox="0 0 24 24"><rect x="4" y="9" width="16" height="11" rx="2"/><path d="M7 9V6.5A1.5 1.5 0 0 1 8.5 5h7A1.5 1.5 0 0 1 17 6.5V9"/><path d="M4 13h16"/></svg>',
    ai: '<svg viewBox="0 0 24 24"><path d="M12 3c.6 4.2 2.8 6.4 7 7-4.2.6-6.4 2.8-7 7-.6-4.2-2.8-6.4-7-7 4.2-.6 6.4-2.8 7-7z"/><path d="M19 15c.3 1.7 1.3 2.7 3 3-1.7.3-2.7 1.3-3 3-.3-1.7-1.3-2.7-3-3 1.7-.3 2.7-1.3 3-3z"/></svg>',
    choice: '<svg viewBox="0 0 24 24"><circle cx="12" cy="12" r="9"/><path d="m8 12.5 2.6 2.5L16 9.5"/></svg>',
    action: '<svg viewBox="0 0 24 24"><path d="M3 12h4l2.5-6 4 12 2.5-6h5"/></svg>',
    next: '<svg viewBox="0 0 24 24"><path d="M4 12a8 8 0 0 1 13.7-5.6L20 8.5"/><path d="M20 3v5.5h-5.5"/><path d="M20 12a8 8 0 0 1-13.7 5.6L4 15.5"/><path d="M4 21v-5.5h5.5"/></svg>',
    // channels
    tv: '<svg viewBox="0 0 24 24"><rect x="3" y="5" width="18" height="12" rx="2"/><path d="M8 21h8M12 17v4"/></svg>',
    creators: '<svg viewBox="0 0 24 24"><circle cx="12" cy="8" r="3.5"/><path d="M5 20c.8-3.6 3.4-5.5 7-5.5s6.2 1.9 7 5.5"/><path d="m18 5 1 1"/></svg>',
    ooh: '<svg viewBox="0 0 24 24"><rect x="3" y="4" width="18" height="10" rx="1.5"/><path d="M8 14v6M16 14v6M5 20h14"/></svg>',
    retail: '<svg viewBox="0 0 24 24"><path d="M4 9h16l-1 11H5z"/><path d="M8 9V7a4 4 0 0 1 8 0v2"/></svg>',
    pr: '<svg viewBox="0 0 24 24"><path d="M4 10v4h3l7 4V6l-7 4z"/><path d="M17 9.5a3.5 3.5 0 0 1 0 5"/></svg>',
    sponsor: '<svg viewBox="0 0 24 24"><path d="M7 4h10v4a5 5 0 0 1-10 0z"/><path d="M7 6H4a3 3 0 0 0 3 4M17 6h3a3 3 0 0 1-3 4"/><path d="M12 13v4M8 21h8M9 17h6"/></svg>',
    digital: '<svg viewBox="0 0 24 24"><path d="M5 4l14 7-6 2-2 6z"/></svg>',
    person: '<svg viewBox="0 0 24 24"><circle cx="12" cy="8" r="3.5"/><path d="M5 20c.8-3.6 3.4-5.5 7-5.5s6.2 1.9 7 5.5"/></svg>'
  };
  function icon(name, cls) { return '<span class="pbi ' + (cls || '') + '" aria-hidden="true">' + I[name] + '</span>'; }

  /* ------------------------------------------------------- visuals -- */
  function spark(points, w, h, band) {
    w = w || 120; h = h || 34;
    var max = Math.max.apply(null, points), min = Math.min.apply(null, points);
    var pt = function (v, i) { return [(i / (points.length - 1)) * (w - 4) + 2, h - 3 - ((v - min) / (max - min || 1)) * (h - 8)]; };
    var d = points.map(function (v, i) { var p = pt(v, i); return (i ? 'L' : 'M') + p[0].toFixed(1) + ' ' + p[1].toFixed(1); }).join(' ');
    var last = pt(points[points.length - 1], points.length - 1);
    var area = d + ' L' + (w - 2) + ' ' + (h - 1) + ' L2 ' + (h - 1) + ' Z';
    var bandSvg = '';
    if (band) {
      var up = points.map(function (v, i) { var p = pt(v * (1 + band), i); return (i ? 'L' : 'M') + p[0].toFixed(1) + ' ' + Math.max(1, p[1]).toFixed(1); }).join(' ');
      var dn = points.slice().reverse().map(function (v, j) { var i = points.length - 1 - j; var p = pt(v * (1 - band), i); return 'L' + p[0].toFixed(1) + ' ' + Math.min(h - 1, p[1]).toFixed(1); }).join(' ');
      bandSvg = '<path class="pbv__band" d="' + up + ' ' + dn + ' Z"/>';
    }
    return '<svg class="pbv__spark" viewBox="0 0 ' + w + ' ' + h + '" preserveAspectRatio="none" aria-hidden="true">' + bandSvg + '<path class="pbv__area" d="' + area + '"/><path class="pbv__line" d="' + d + '"/><circle class="pbv__dot" cx="' + last[0].toFixed(1) + '" cy="' + last[1].toFixed(1) + '" r="2.4"/></svg>';
  }
  function ring(pct, label) {
    var r = 9, c = 2 * Math.PI * r;
    return '<span class="pbv__ring" aria-hidden="true"><svg viewBox="0 0 24 24"><circle cx="12" cy="12" r="' + r + '" class="pbv__ring-bg"/><circle cx="12" cy="12" r="' + r + '" class="pbv__ring-fg" stroke-dasharray="' + (c * pct).toFixed(1) + ' ' + c.toFixed(1) + '" transform="rotate(-90 12 12)"/></svg><b>' + label + '</b></span>';
  }
  function bar(label, pct, cls, note) {
    return '<div class="pbv__bar ' + (cls || '') + '"><span class="pbv__bar-l">' + label + '</span><span class="pbv__bar-t"><i style="width:' + Math.round(pct * 100) + '%"></i></span><span class="pbv__bar-n">' + (note || '') + '</span></div>';
  }
  function chip(html, cls) { return '<span class="pbv__chip ' + (cls || '') + '">' + html + '</span>'; }

  var V = {
    record: function () {
      return '<div class="pbv pbv--goal"><span class="pbv__num">$2m</span><span class="pbv__cities">' +
        ['A', 'B', 'C'].map(function (c) { return '<span class="pbv__city"><i></i>' + c + '</span>'; }).join('') +
        '<small>3 cities · new buyers</small></span></div>';
    },
    proposal: function () {
      return '<div class="pbv pbv--channels">' +
        [['tv', 'TV'], ['creators', 'Creators'], ['ooh', 'OOH'], ['retail', 'Retail'], ['pr', 'PR']].map(function (c) { return '<span class="pbv__ch">' + icon(c[0]) + '<small>' + c[1] + '</small></span>'; }).join('') +
        '<span class="pbv__ch pbv__ch--q">' + icon('sponsor') + '<small>1 yr?</small></span></div>';
    },
    expectation: function () {
      return '<div class="pbv pbv--spark">' + spark([3, 4, 4, 6, 7, 9, 12, 14], 140, 36, 0.18) + '<small>New buyers, with a range to adapt</small></div>';
    },
    policy: function () {
      return '<div class="pbv pbv--rules">' + ring(0.2, '20%') + chip(icon('retail') + 'Stock ✓') + chip(icon('person') + 'Finance on annual') + '</div>';
    },
    evidence: function () {
      return '<div class="pbv pbv--bars">' + bar('Launch A', 0.82, '', '82% fit') + bar('Launch B', 0.64, 'is-warn', 'stock delay') + bar('Sponsorship', 0.4, 'is-gap', 'gap') + '</div>';
    },
    authorization: function () {
      return '<div class="pbv pbv--phase">' +
        '<div class="pbv__ph"><span>City A</span><i class="on" style="width:70%"></i></div>' +
        '<div class="pbv__ph"><span>City B</span><i class="on" style="width:70%"></i></div>' +
        '<div class="pbv__ph"><span>City C</span><i class="hold" style="width:40%"></i><small>hold</small></div>' +
        '<div class="pbv__ph"><span>Sponsor</span><i class="pilot" style="width:25%"></i><small>pilot</small></div></div>';
    },
    approval: function () {
      return '<div class="pbv pbv--who">' + chip(icon('person') + 'Marketing', 'is-on') + chip(icon('person') + 'Finance', 'is-on') + chip('Revised plan ✓', 'is-ok') + '</div>';
    },
    execution: function () {
      return '<div class="pbv pbv--track"><span class="pbv__seg"><i class="a" style="width:58%"></i><i class="b" style="width:30%"></i><i class="c" style="width:12%"></i></span><small><b class="a"></b>Committed <b class="b"></b>Delivered <b class="c"></b>Off plan</small></div>';
    },
    outcome: function () {
      return '<div class="pbv pbv--grades">' + chip('Decision', 'is-ok') + chip('Execution', 'is-warn') + chip('Outcome', 'is-gap') + '<small>Graded separately</small></div>';
    }
  };

  /* --------------------------------------------------------- model -- */
  var STEPS = [
    { key: 'record', icon: 'goal', label: 'Our goal', short: 'New buyers in 3 cities. $2m.', full: 'Win new buyers in three cities. $2m total.' },
    { key: 'proposal', icon: 'question', label: 'The question', short: 'Integrated launch, plus a year of sponsorship?', full: 'An integrated launch plus an annual sponsorship?' },
    { key: 'expectation', icon: 'bet', label: 'Our bet', short: 'New-buyer growth, room to adapt.', full: 'New-buyer growth, with room to adapt.' },
    { key: 'policy', icon: 'rules', label: 'Our rules', short: 'Protect 20%. Confirm stock. Review annual deals.', full: 'Protect 20%. Confirm stock. Review annual deals.' },
    { key: 'evidence', icon: 'experience', label: 'Our experience', short: 'Two similar launches. One sponsorship, gaps flagged.', full: 'Similar launches and a prior sponsorship, with gaps flagged.' },
    { key: 'authorization', icon: 'ai', label: 'AI suggestion', short: 'Phase the cities. Pilot the sponsorship.', full: 'Phase the cities. Pilot the sponsorship.' },
    { key: 'approval', icon: 'choice', label: 'Our choice', short: 'Marketing and finance review the revised plan.', full: 'Review the revised plan with marketing and finance.' },
    { key: 'execution', icon: 'action', label: 'The action', short: 'Track commitments, delivery, departures.', full: 'Track commitments, delivery and departures from the plan.' },
    { key: 'outcome', icon: 'next', label: 'What comes next', short: 'Grade. Estimate alternatives. Refine.', full: 'Grade results. Estimate alternatives. Refine the next launch.' }
  ];
  var byKey = {}; STEPS.forEach(function (s, i) { s.i = i; byKey[s.key] = s; });

  function escapeHtml(s) { return String(s).replace(/[&<>"']/g, function (c) { return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]; }); }

  /* ------------------------------------------------------ renderers -- */
  function entryHtml(s, mode) {
    var text = mode === 'full' ? s.full : s.short;
    var val = mode === 'full'
      ? '<button type="button" class="pbe__val" data-pb-edit="' + s.key + '" aria-label="' + escapeHtml(s.label) + ', click to draft a note">' + escapeHtml(text) + '</button>'
      : '<p class="pbe__val">' + escapeHtml(text) + '</p>';
    return '<article class="pbe pbe--' + s.key + '" data-pb-entry="' + s.key + '">' +
      '<div class="pbe__head">' + icon(s.icon, 'pbi--step') + '<span class="pbe__label">' + s.label + '</span><span class="pbe__n">' + (s.i + 1) + '</span></div>' +
      val + V[s.key]() + '</article>';
  }
  function rowHtml(s) {
    return '<button type="button" class="pbr" data-pb-row="' + s.key + '" aria-label="' + escapeHtml(s.label) + ': ' + escapeHtml(s.short) + '">' + icon(s.icon) + '<span>' + s.label + '</span><small>' + escapeHtml(s.short) + '</small></button>';
  }

  /* ---------------------------------------------------------- state -- */
  var filled = [], drafts = [], seq = 0;
  var els = {
    card: document.getElementById('record'),
    feed: document.querySelector('[data-pb-feed]'),
    dots: document.querySelector('[data-pb-dots]'),
    strip: document.querySelector('[data-pb-strip]'),
    count: document.querySelectorAll('[data-pb-count]'),
    dialog: document.querySelector('[data-pb-dialog]'),
    dialogBody: document.querySelector('[data-pb-dialog-body]'),
    full: document.querySelector('[data-pb-full]'),
    events: document.querySelectorAll('[data-pb-events]')
  };

  // dots
  els.dots.innerHTML = STEPS.map(function (s) { return '<li data-pb-dot="' + s.key + '" title="' + s.label + '"></li>'; }).join('');

  function renderWizard() {
    var n = filled.length;
    els.count.forEach(function (c) { c.textContent = n + ' of ' + STEPS.length; });
    STEPS.forEach(function (s) { els.dots.querySelector('[data-pb-dot="' + s.key + '"]').classList.toggle('is-on', filled.indexOf(s.key) > -1); });
    var html = '';
    if (!n) {
      html = '<div class="pb__listen"><span class="pb__dots"><i></i><i></i><i></i></span>Reading the brief…</div>';
    } else {
      var prev = filled.slice(-3, -1), cur = byKey[filled[n - 1]];
      html += prev.map(function (k) { return rowHtml(byKey[k]); }).join('');
      html += entryHtml(cur, 'wizard');
      if (n < STEPS.length) html += '<div class="pb__listen"><span class="pb__dots"><i></i><i></i><i></i></span>' + byKey[STEPS[n].key].label.replace(/^Our |^The /, function (m) { return m; }) + ' arrives as you read</div>';
      else html += '<div class="pb__listen is-done">' + icon('choice') + 'Playbook complete</div>';
    }
    els.feed.innerHTML = html;
    // strip
    if (n) { var c = byKey[filled[n - 1]]; els.strip.innerHTML = icon(c.icon) + '<b>' + c.label + '</b><span>' + escapeHtml(c.short) + '</span><small>' + n + '/' + STEPS.length + '</small>'; }
    else els.strip.innerHTML = icon('goal') + '<b>Playbook</b><span>Reading the brief…</span><small>0/' + STEPS.length + '</small>';
  }

  function renderFull(target, all) {
    var keys = all ? STEPS.map(function (s) { return s.key; }) : filled;
    target.innerHTML = keys.map(function (k) { return entryHtml(byKey[k], 'full'); }).join('');
  }
  function renderRows(target) {
    target.innerHTML = filled.map(function (k) { return rowHtml(byKey[k]); }).join('');
  }

  function fill(key) {
    if (filled.indexOf(key) > -1) return;
    filled.push(key);
    renderWizard();
    if (els.full) renderRows(els.full);
    if (els.dialog && els.dialog.open) renderFull(els.dialogBody, true);
  }
  function fillAll() { STEPS.forEach(function (s) { fill(s.key); }); }

  /* ------------------------------------------------ draft-note edit -- */
  function tryEdit(btn) {
    var key = btn.getAttribute('data-pb-edit'), s = byKey[key];
    var original = btn.textContent;
    var input = document.createElement('input');
    input.type = 'text'; input.className = 'pbe__input'; input.value = original; input.setAttribute('aria-label', s.label + ', draft note for review');
    btn.replaceWith(input); input.focus(); input.select();
    var done = false;
    function restore() { if (done) return; done = true; input.replaceWith(btn); }
    function commit() {
      var proposed = input.value.trim(); restore();
      if (!proposed || proposed === original) return;
      seq += 1;
      var li = '<li><b>Draft ' + String(seq).padStart(2, '0') + '</b><span>' + escapeHtml(s.label) + ': “' + escapeHtml(proposed) + '” · ready for team review · demo only</span></li>';
      drafts.push(li);
      els.events.forEach(function (ul) { ul.innerHTML = drafts.join(''); ul.scrollTop = ul.scrollHeight; });
      setTimeout(function () { btn.focus(); }, 0);
    }
    input.addEventListener('keydown', function (e) {
      if (e.key === 'Escape') { e.preventDefault(); restore(); setTimeout(function () { btn.focus(); }, 0); }
      if (e.key === 'Enter') { e.preventDefault(); commit(); }
    });
    input.addEventListener('blur', function () { if (!done) commit(); });
  }
  document.addEventListener('click', function (e) {
    var b = e.target.closest('[data-pb-edit]'); if (b) { tryEdit(b); return; }
    if (e.target.closest('[data-pb-open]') || e.target.closest('[data-pb-row]') || e.target.closest('[data-pb-strip]')) { openDialog(); return; }
    if (e.target.closest('[data-pb-close]')) { closeDialog(); }
  });

  /* --------------------------------------------------------- dialog -- */
  function openDialog() {
    if (!els.dialog) return;
    renderFull(els.dialogBody, true);
    els.dialog.querySelectorAll('[data-pb-events]').forEach(function (ul) { ul.innerHTML = drafts.join(''); });
    if (typeof els.dialog.showModal === 'function') els.dialog.showModal(); else els.dialog.setAttribute('open', '');
    document.documentElement.classList.add('pb-modal');
  }
  function closeDialog() {
    if (!els.dialog) return;
    if (els.dialog.open && typeof els.dialog.close === 'function') els.dialog.close(); else els.dialog.removeAttribute('open');
    document.documentElement.classList.remove('pb-modal');
  }
  if (els.dialog) {
    els.dialog.addEventListener('close', function () { document.documentElement.classList.remove('pb-modal'); });
    els.dialog.addEventListener('click', function (e) { if (e.target === els.dialog) closeDialog(); });
  }

  renderWizard();
  return { fill: fill, fillAll: fillAll, steps: STEPS, open: openDialog, close: closeDialog, filled: filled };
})();
