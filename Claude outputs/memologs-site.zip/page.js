/* MemoLogs page script. Everything bespoke lives here; the engine is untouched.
   Three parts: the 3D mark (hero + close), the demo scenario (computed from
   data in this file, labelled a sample on the page), and the decision record
   (the signature move: it fills as you read and only ever appends). */
(function () {
  'use strict';

  var reduce = matchMedia('(prefers-reduced-motion: reduce)').matches;
  var smallMQ = matchMedia('(max-width: 860px)');
  var fine = matchMedia('(hover: hover) and (pointer: fine)').matches;
  var clamp01 = function (x) { return x < 0 ? 0 : x > 1 ? 1 : x; };
  var smooth = function (x) { x = clamp01(x); return x * x * (3 - 2 * x); };
  var range = function (x, a, b) { return smooth((x - a) / (b - a)); };
  var lerp = function (a, b, t) { return a + (b - a) * t; };
  var pOf = function (el) { return parseFloat(getComputedStyle(el).getPropertyValue('--sc-p')) || 0; };

  var heroAct = document.querySelector('[data-ml-hero]');
  var closeAct = document.querySelector('[data-ml-close]');
  var demoAct = document.querySelector('[data-ml-demo]');
  var heroStage = heroAct.querySelector('[data-sc-stage]');
  var closeStage = closeAct.querySelector('[data-sc-stage]');

  /* ======================================================= the 3D mark == */
  var views = {
    hero: document.querySelector('canvas[data-ml-view="hero"]'),
    close: document.querySelector('canvas[data-ml-view="close"]')
  };
  var gl = null;

  function buildScene() {
    if (!window.THREE) return null;
    var renderer;
    try {
      renderer = new THREE.WebGLRenderer({ antialias: true, alpha: true, powerPreference: 'high-performance' });
    } catch (e) { return null; }
    renderer.setPixelRatio(Math.min(devicePixelRatio || 1, 1.75));
    renderer.outputEncoding = THREE.sRGBEncoding;
    renderer.toneMapping = THREE.ACESFilmicToneMapping;
    renderer.toneMappingExposure = 0.82;

    var scene = new THREE.Scene();
    var camera = new THREE.PerspectiveCamera(36, 1, 0.1, 100);
    camera.position.set(0, 0.2, 10);

    scene.add(new THREE.HemisphereLight(0x6fe0cb, 0x06101c, 0.26));
    var key = new THREE.DirectionalLight(0xe6fffa, 0.95); key.position.set(4, 6, 5); scene.add(key);
    var rim = new THREE.DirectionalLight(0x2ef0cb, 0.6); rim.position.set(-5, 2, -3); scene.add(rim);
    var under = new THREE.PointLight(0x1fd9b6, 0.45, 30); under.position.set(0, -5, 4); scene.add(under);

    var bead = new THREE.MeshPhysicalMaterial({
      color: 0x12c4a2, roughness: 0.36, metalness: 0.0,
      clearcoat: 0.9, clearcoatRoughness: 0.2,
      emissive: 0x0a5a4d, emissiveIntensity: 0.22
    });
    var rodMat = new THREE.MeshPhysicalMaterial({ color: 0x12a58b, roughness: 0.5, metalness: 0.0, clearcoat: 0.5, emissive: 0x063d35, emissiveIntensity: 0.2 });
    var holeMat = new THREE.MeshStandardMaterial({ color: 0x07322f, roughness: 0.95, metalness: 0 });

    var group = new THREE.Group();
    scene.add(group);

    function makeBead(r) {
      var g = new THREE.Group();
      var s = new THREE.Mesh(new THREE.SphereGeometry(r, 48, 32), bead);
      var hole = new THREE.Mesh(new THREE.CylinderGeometry(r * 0.27, r * 0.27, r * 2.02, 32, 1, false), holeMat);
      hole.rotation.x = Math.PI / 2;
      g.add(s); g.add(hole);
      return g;
    }

    var HUB_R = 1.0, SAT_R = 0.76, DIST = 2.75;
    var hub = makeBead(HUB_R);
    group.add(hub);

    var angles = [90, 162, 18, 234, 306];
    var home = angles.map(function (a) { var t = a * Math.PI / 180; return new THREE.Vector3(Math.cos(t) * DIST, Math.sin(t) * DIST, 0); });
    // scattered starting positions, authored, not random: wide, uneven, some behind
    var away = [
      new THREE.Vector3(-0.6, 2.5, -2.4), new THREE.Vector3(-1.1, -0.9, -1.6), new THREE.Vector3(3.6, 2.2, -3.0),
      new THREE.Vector3(0.6, -3.0, -0.8), new THREE.Vector3(3.9, -1.3, -1.8)
    ];
    var sats = home.map(function () { var b = makeBead(SAT_R); group.add(b); return b; });

    var rods = home.map(function (v, i) {
      var len = DIST - HUB_R * 0.55 - SAT_R * 0.55;
      var geo = new THREE.CylinderGeometry(0.2, 0.2, len, 24, 1, false);
      geo.translate(0, len / 2, 0);            // pivot at the hub end
      var m = new THREE.Mesh(geo, rodMat);
      var dir = v.clone().normalize();
      m.quaternion.setFromUnitVectors(new THREE.Vector3(0, 1, 0), dir);
      m.position.copy(dir.clone().multiplyScalar(HUB_R * 0.55));
      m.scale.set(1, 0.0001, 1);
      group.add(m);
      return m;
    });

    var state = { s: 0, c: 0, mode: 'hero', px: 0, py: 0, tx: 0, ty: 0, t: 0 };
    var tmp = new THREE.Vector3();

    function update(dt) {
      state.t += dt;
      var s = state.s, c = state.c, t = state.t;
      var mobile = smallMQ.matches;
      // hub
      var hs = lerp(0.42, 1, range(s, 0, 0.55));
      hub.scale.setScalar(hs);
      // satellites drift while loose, lock while ordered
      for (var i = 0; i < 5; i++) {
        var k = range(s, 0.05 + i * 0.07, 0.62 + i * 0.07);
        tmp.copy(away[i]); if (mobile) { tmp.y = tmp.y < 0 ? tmp.y * 0.45 + 0.6 : tmp.y * 0.8; tmp.x *= 0.8; }
        tmp.lerp(home[i], k);
        var loose = 1 - k;
        tmp.x += Math.sin(t * 0.7 + i * 1.7) * 0.35 * loose;
        tmp.y += Math.cos(t * 0.55 + i * 2.3) * 0.3 * loose;
        tmp.z += Math.sin(t * 0.4 + i) * 0.4 * loose;
        sats[i].position.copy(tmp);
        sats[i].rotation.set(0.3 * loose * Math.sin(t + i), 0.4 * loose * Math.cos(t * 0.8 + i), 0);
        sats[i].scale.setScalar(lerp(0.82, 1, k));
        // rods: the four that exist in the mark, then the fifth at the close
        var rk = i === 0 ? range(c, 0.18, 0.62) : range(s, 0.38 + i * 0.05, 0.86 + i * 0.03);
        rods[i].scale.set(1, Math.max(rk, 0.0001), 1);
        rods[i].visible = rk > 0.02;
      }
      // group pose
      var settled = range(s, 0.2, 0.9);
      var idle = 0.05 * Math.sin(t * 0.35);
      var targetRy = lerp(-0.85, 0.0, settled) + idle + state.px * 0.28;
      var targetRx = lerp(0.35, 0.08, settled) - state.py * 0.18;
      group.rotation.y += (targetRy - group.rotation.y) * 0.08;
      group.rotation.x += (targetRx - group.rotation.x) * 0.08;
      if (state.mode === 'close') {
        group.rotation.y += ((0.0 + state.px * 0.2 + idle * 0.5) - group.rotation.y) * 0.08;
        group.rotation.x += ((0.04 - state.py * 0.1) - group.rotation.x) * 0.08;
      }
      // placement
      var gx, gy, cz;
      if (mobile) {
        gx = 0; gy = lerp(6.8, 5.4, settled); cz = lerp(31, 32, settled);
        if (state.mode === 'close') { gx = 0; gy = 8.0; cz = 33; }
      } else {
        gx = lerp(3.6, 3.4, settled); gy = lerp(0.1, 0.4, settled); cz = lerp(15.0, 17.5, settled);
        if (reduce) { gx = 5.2; gy = 0.2; cz = 18; }
        if (state.mode === 'close') { gx = 2.6; gy = -1.0; cz = 21; }
      }
      group.position.set(gx, gy, 0);
      camera.position.z += (cz - camera.position.z) * 0.1;
      camera.lookAt(gx * 0.6, gy * 0.5, 0);
    }

    function size(w, h) {
      renderer.setSize(w, h, false);
      camera.aspect = w / h; camera.updateProjectionMatrix();
    }

    return { renderer: renderer, scene: scene, camera: camera, update: update, size: size, state: state };
  }

  gl = buildScene();
  if (!gl) document.documentElement.classList.add('no-webgl');

  // Which display canvases are on screen. The offscreen renderer draws once per
  // frame and each visible view copies it; nothing renders while both are off.
  var visible = { hero: true, close: false };
  if ('IntersectionObserver' in window) {
    var vio = new IntersectionObserver(function (es) {
      es.forEach(function (e) { visible[e.target.querySelector('[data-ml-view]').getAttribute('data-ml-view')] = e.isIntersecting; });
    }, { threshold: 0 });
    vio.observe(views.hero.parentNode); vio.observe(views.close.parentNode);
  }

  var last = performance.now(), W = 0, H = 0;
  function fit() {
    var r = (visible.close && !visible.hero ? views.close : views.hero).getBoundingClientRect();
    var dpr = Math.min(devicePixelRatio || 1, 1.75);
    var w = Math.max(1, Math.round(r.width)), h = Math.max(1, Math.round(r.height));
    if (w !== W || h !== H) {
      W = w; H = h;
      gl.size(w, h);
      [views.hero, views.close].forEach(function (cv) { cv.width = Math.round(w * dpr); cv.height = Math.round(h * dpr); });
    }
  }

  function frame(now) {
    requestAnimationFrame(frame);
    var dt = Math.min(0.05, (now - last) / 1000); last = now;
    // scroll state
    var ph = pOf(heroAct), pc = pOf(closeAct);
    var closeOn = visible.close && !visible.hero;
    if (gl) {
      gl.state.mode = closeOn ? 'close' : 'hero';
      gl.state.s = closeOn ? 1 : (reduce ? 1 : range(ph, 0.0, 0.78));
      gl.state.c = closeOn ? (reduce ? 1 : pc) : 0;
      gl.state.px += (gl.state.tx - gl.state.px) * 0.06;
      gl.state.py += (gl.state.ty - gl.state.py) * 0.06;
      if (visible.hero || visible.close) {
        fit();
        gl.update(reduce ? 0 : dt);
        gl.renderer.render(gl.scene, gl.camera);
        var cv = closeOn ? views.close : views.hero;
        var ctx = cv.getContext('2d');
        ctx.clearRect(0, 0, cv.width, cv.height);
        ctx.drawImage(gl.renderer.domElement, 0, 0, cv.width, cv.height);
      }
    }
    heroStage.setAttribute('data-sc-verify-state', 's=' + (gl ? gl.state.s : 0).toFixed(2) + ' p=' + ph.toFixed(2));
    closeStage.setAttribute('data-sc-verify-state', 'c=' + (gl ? gl.state.c : 0).toFixed(2));
    tickRecord(ph, pc);
    tickDwell();
  }
  requestAnimationFrame(frame);

  if (fine && !reduce && gl) {
    addEventListener('pointermove', function (e) {
      gl.state.tx = (e.clientX / innerWidth - 0.5) * 2;
      gl.state.ty = (e.clientY / innerHeight - 0.5) * 2;
    }, { passive: true });
  }

  /* =========================================================== the bar == */
  var bar = document.getElementById('bar');
  addEventListener('scroll', function () { bar.classList.toggle('is-scrolled', scrollY > 40); }, { passive: true });

  /* Authored product illustration, not a live AI or authorization engine. */
  var $ = function (k) { return document.querySelector('[data-ml="' + k + '"]'); };
  $('proposalTitle').textContent = 'The brief: win three new markets.';
  $('title').textContent = '“What is the right launch investment?”';
  $('t1').textContent = 'Two earlier launches match. One had stock delays; the sponsorship’s effect on new buyers is unclear.';
  $('t1state').textContent = 'Context found';
  $('t2').textContent = 'The annual deal eats into the 20% reserve and needs finance approval. One city still lacks confirmed stock.';
  $('t2state').textContent = 'Revise plan';
  $('t3').textContent = 'A phased rollout and a short sponsorship pilot beat a simultaneous launch on the evidence available.';
  $('t3state').textContent = 'Mixed evidence';
  $('t3state').classList.add('test__state--limited');
  $('result').textContent = 'Stage the launch. Preserve your options.';
  $('constraints').innerHTML = '<li><span>Recommend</span><span>Launch in two ready cities. Hold the third until stock is confirmed.</span></li><li><span>Reshape</span><span>Negotiate a short sponsorship pilot and protect the reserve.</span></li><li><span>Measure</span><span>Agree new-buyer targets and a comparison plan before committing.</span></li>';
  $('reason').textContent = 'The team reviews the revised investment case. Finance approval and the agreed readiness checks still apply.';
  $('rules').textContent = 'AI proposes and explains. Your approved spending rules determine what is allowed. This walkthrough uses fictional data.';
  var dwellP = -1, dwellSince = 0;
  function tickDwell() {
    var p = pOf(demoAct);
    if (p <= 0.6 || p >= 0.98) { demoAct.classList.remove('is-dwelling'); dwellP = p; return; }
    if (Math.abs(p - dwellP) > 0.002) { dwellP = p; dwellSince = performance.now(); demoAct.classList.remove('is-dwelling'); return; }
    if (performance.now() - dwellSince > 900) demoAct.classList.add('is-dwelling');
  }

  /* ============================== the playbook: fills as you read == */
  var record = document.getElementById('record');
  var PB = window.MLPlaybook;
  var acts = {};
  Array.prototype.forEach.call(document.querySelectorAll('[data-ml-act]'), function (el) { acts[el.getAttribute('data-ml-act')] = el; });
  // triggers: [act, progress, step]
  var triggers = [
    ['missing', 0.55, 'record'], ['path', 0.5, 'policy'],
    ['demo', 0.08, 'proposal'], ['demo', 0.14, 'expectation'], ['demo', 0.5, 'evidence'], ['demo', 0.66, 'authorization'], ['demo', 0.84, 'approval'],
    ['agents', 0.5, 'execution'], ['forwhom', 0.35, 'outcome']
  ];
  function tickRecord(ph, pc) {
    for (var i = 0; i < triggers.length; i++) {
      var t = triggers[i];
      if (PB.filled.indexOf(t[2]) < 0 && acts[t[0]] && pOf(acts[t[0]]) >= t[1]) PB.fill(t[2]);
    }
    var on = !visible.hero && !visible.close;
    record.classList.toggle('is-on', on);
    var full = document.querySelector('[data-pb-full-wrap]');
    if (full) full.classList.toggle('is-complete', pc > 0.35);
  }
  // whatever the visitor never scrolled past is still part of the playbook: fill the rest on arrival
  var closeIO = new IntersectionObserver(function (es) {
    if (es.some(function (e) { return e.isIntersecting; })) PB.fillAll();
  }, { rootMargin: '0px 0px -30% 0px' });
  closeIO.observe(closeAct);

  /* keyboard: a focused rail item should scroll its panel into view */
  document.querySelectorAll('.station').forEach(function (s) { s.setAttribute('tabindex', '0'); });

  if (smallMQ.matches) {
    var mc = { '.proposal': '0 0.36 0 0.06', '.test:nth-child(1)': '0.34 0.64 0.06 0.06', '.test:nth-child(2)': '0.40 0.64 0.06 0.06', '.test:nth-child(3)': '0.46 0.64 0.06 0.06', '.verdict': '0.66 0.94 0.06 0.06', '.demo__close': '0.88 1 0.06 0.1' };
    Object.keys(mc).forEach(function (sel) { var el = demoAct.querySelector(sel); if (el) el.setAttribute('data-sc-cue', mc[sel]); });
  }
  ScrollCraft.mount(document.body);
})();
